# SECRETS BACKUP - ADD THESE TO AZURE KEY VAULT

**IMPORTANT: Delete this file after adding secrets to Key Vault!**

## DEV Environment (Key Vault: ocioomcpdevmodkv01)

| Key Vault Secret Name | Value |
|-----------------------|-------|
| admin-user-password | TstAdmin2025!SecureP@ss |
| azure-client-secret | JhT8Q~_lTIqZCcKiOCHrgw-X9ELp9L3G46mrNbeD |
| azure-openai-api-key | 3WR8VMNC2vovVmGQd3bV09HXFEB41aXfgtFQeUfp9xVYWBbwkXrQJQQJ99BKACHYHv6XJ3w3AAAAACOGlaBC |
| aws-access-key-id | AKIA5DOV5EKKN4US6IFJ |
| aws-secret-access-key | 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 |
| azure-storage-account-key-milvus | JYPtbqPFF+n5r3qmHB9xkdS7tG+J/Sw/lISaBffEkyW4xdHbqRTF8MVG/DW6j9xTtsF008AeJUt3+AStQf93zw== |
| azure-storage-account-key-platform | ZDu7OQxLMmZy7aVIJFHm6r2dYdbF+kVCSP6fu5yGxrALbLKil7wlL94457sHYky5ZzHB37Tc66Pi+AStsz5Thg== |

### Additional secrets to generate/set:
| Key Vault Secret Name | Description |
|-----------------------|-------------|
| jwt-secret | Generate: openssl rand -base64 64 |
| api-secret-key | Generate: openssl rand -base64 32 |
| signing-secret | Generate: openssl rand -base64 32 |
| postgres-password | Set to your PostgreSQL password |
| redis-password | Set to your Redis password |
| milvus-password | Default: Milvus123456 |
| code-manager-internal-key | Generate: openssl rand -base64 32 |
| flowise-secret-key | Generate: openssl rand -base64 32 |

---

## STG Environment (Key Vault: omcp-stg-kv-1)

| Key Vault Secret Name | Value |
|-----------------------|-------|
| admin-user-password | StgAdmin2025!SecureP@ss |
| azure-client-secret | KcI8Q~BQp1~4bkLoMTIDAmAASMF~YMhU.xVh1aJO |
| aws-access-key-id | AKIA5DOV5EKKN4US6IFJ |
| aws-secret-access-key | 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 |
| azure-storage-account-key | 4U2sFmbM/79PIqVbsavEZVGEsn1QrtmPaUdUtwGoY85kWyzD81LhSt/4iB5bDGP1dvOgjP5ftpEW+AStmJn19w== |

### Additional secrets to generate/set:
| Key Vault Secret Name | Description |
|-----------------------|-------------|
| jwt-secret | Generate: openssl rand -base64 64 |
| api-secret-key | Generate: openssl rand -base64 32 |
| signing-secret | Generate: openssl rand -base64 32 |
| postgres-password | Set to your PostgreSQL password |
| redis-password | Set to your Redis password |
| milvus-password | Default: Milvus123456 |
| code-manager-internal-key | Generate: openssl rand -base64 32 |
| flowise-secret-key | Generate: openssl rand -base64 32 |

---

## Azure CLI Commands to Add Secrets

```bash
# DEV
az keyvault secret set --vault-name ocioomcpdevmodkv01 --name "admin-user-password" --value "TstAdmin2025!SecureP@ss"
az keyvault secret set --vault-name ocioomcpdevmodkv01 --name "azure-client-secret" --value "JhT8Q~_lTIqZCcKiOCHrgw-X9ELp9L3G46mrNbeD"
az keyvault secret set --vault-name ocioomcpdevmodkv01 --name "azure-openai-api-key" --value "3WR8VMNC2vovVmGQd3bV09HXFEB41aXfgtFQeUfp9xVYWBbwkXrQJQQJ99BKACHYHv6XJ3w3AAAAACOGlaBC"
az keyvault secret set --vault-name ocioomcpdevmodkv01 --name "aws-access-key-id" --value "AKIA5DOV5EKKN4US6IFJ"
az keyvault secret set --vault-name ocioomcpdevmodkv01 --name "aws-secret-access-key" --value "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"
az keyvault secret set --vault-name ocioomcpdevmodkv01 --name "azure-storage-account-key-milvus" --value "JYPtbqPFF+n5r3qmHB9xkdS7tG+J/Sw/lISaBffEkyW4xdHbqRTF8MVG/DW6j9xTtsF008AeJUt3+AStQf93zw=="
az keyvault secret set --vault-name ocioomcpdevmodkv01 --name "azure-storage-account-key-platform" --value "ZDu7OQxLMmZy7aVIJFHm6r2dYdbF+kVCSP6fu5yGxrALbLKil7wlL94457sHYky5ZzHB37Tc66Pi+AStsz5Thg=="

# Generate and set other secrets
az keyvault secret set --vault-name ocioomcpdevmodkv01 --name "jwt-secret" --value "$(openssl rand -base64 64)"
az keyvault secret set --vault-name ocioomcpdevmodkv01 --name "api-secret-key" --value "$(openssl rand -base64 32)"
az keyvault secret set --vault-name ocioomcpdevmodkv01 --name "signing-secret" --value "$(openssl rand -base64 32)"
az keyvault secret set --vault-name ocioomcpdevmodkv01 --name "code-manager-internal-key" --value "$(openssl rand -base64 32)"
az keyvault secret set --vault-name ocioomcpdevmodkv01 --name "flowise-secret-key" --value "$(openssl rand -base64 32)"
az keyvault secret set --vault-name ocioomcpdevmodkv01 --name "milvus-password" --value "Milvus123456"

# STG
az keyvault secret set --vault-name omcp-stg-kv-1 --name "admin-user-password" --value "StgAdmin2025!SecureP@ss"
az keyvault secret set --vault-name omcp-stg-kv-1 --name "azure-client-secret" --value "KcI8Q~BQp1~4bkLoMTIDAmAASMF~YMhU.xVh1aJO"
az keyvault secret set --vault-name omcp-stg-kv-1 --name "aws-access-key-id" --value "AKIA5DOV5EKKN4US6IFJ"
az keyvault secret set --vault-name omcp-stg-kv-1 --name "aws-secret-access-key" --value "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"
az keyvault secret set --vault-name omcp-stg-kv-1 --name "azure-storage-account-key" --value "4U2sFmbM/79PIqVbsavEZVGEsn1QrtmPaUdUtwGoY85kWyzD81LhSt/4iB5bDGP1dvOgjP5ftpEW+AStmJn19w=="
```

**DELETE THIS FILE AFTER ADDING SECRETS TO KEY VAULT!**
