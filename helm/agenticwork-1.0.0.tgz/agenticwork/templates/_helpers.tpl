{{/*
Expand the name of the chart.
*/}}
{{- define "agenticwork.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "agenticwork.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "agenticwork.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "agenticwork.labels" -}}
helm.sh/chart: {{ include "agenticwork.chart" . }}
{{ include "agenticwork.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "agenticwork.selectorLabels" -}}
app.kubernetes.io/name: {{ include "agenticwork.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "agenticwork.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "agenticwork.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Redis service name for Bitnami Redis subchart
When sentinel is enabled, service name is {{ .Release.Name }}-redis (routes to current master)
When sentinel is disabled, service name is {{ .Release.Name }}-redis-master
*/}}
{{- define "agenticwork.redis.serviceName" -}}
{{- if and .Values.redis .Values.redis.sentinel .Values.redis.sentinel.enabled -}}
{{- printf "%s-redis" .Release.Name }}
{{- else -}}
{{- printf "%s-redis-master" .Release.Name }}
{{- end -}}
{{- end }}

{{/*
Redis port
*/}}
{{- define "agenticwork.redis.port" -}}
{{- if .Values.redis.master }}
{{- .Values.redis.master.service.ports.redis | default 6379 }}
{{- else if .Values.redis.service }}
{{- .Values.redis.service.ports.redis | default 6379 }}
{{- else }}
{{- 6379 }}
{{- end }}
{{- end }}

{{/*
Redis service URL for Bitnami Redis subchart (with password if auth enabled)
*/}}
{{- define "agenticwork.redis.url" -}}
{{- if and .Values.redis.auth .Values.redis.auth.enabled .Values.redis.auth.password -}}
{{- printf "redis://:%s@%s:%s" .Values.redis.auth.password (include "agenticwork.redis.serviceName" .) (include "agenticwork.redis.port" .) }}
{{- else -}}
{{- printf "redis://%s:%s" (include "agenticwork.redis.serviceName" .) (include "agenticwork.redis.port" .) }}
{{- end -}}
{{- end }}

{{/*
Redis password
*/}}
{{- define "agenticwork.redis.password" -}}
{{- if .Values.redis.auth.password -}}
{{- .Values.redis.auth.password }}
{{- else -}}
{{- "" }}
{{- end -}}
{{- end }}

{{/*
PostgreSQL service name for Bitnami PostgreSQL subchart
When architecture is replication, service name is {{ .Release.Name }}-postgresql-primary
When architecture is standalone, service name is {{ .Release.Name }}-postgresql
*/}}
{{- define "agenticwork.postgresql.serviceName" -}}
{{- if and .Values.postgres .Values.postgres.enabled -}}
{{- printf "%s-postgres" .Release.Name }}
{{- else if eq (default "standalone" .Values.postgresql.architecture) "replication" -}}
{{- printf "%s-postgresql-primary" .Release.Name }}
{{- else -}}
{{- printf "%s-postgresql" .Release.Name }}
{{- end -}}
{{- end }}

{{/*
PostgreSQL port (pgpool default is 5432)
*/}}
{{- define "agenticwork.postgresql.port" -}}
{{- 5432 }}
{{- end }}

{{/*
PostgreSQL username
*/}}
{{- define "agenticwork.postgresql.username" -}}
{{- if and .Values.postgres .Values.postgres.enabled -}}
{{- .Values.postgres.username | default "agenticwork" }}
{{- else if .Values.postgresql.auth -}}
{{- .Values.postgresql.auth.username }}
{{- else -}}
{{- "agenticwork" }}
{{- end -}}
{{- end }}

{{/*
PostgreSQL password
*/}}
{{- define "agenticwork.postgresql.password" -}}
{{- if and .Values.postgres .Values.postgres.enabled -}}
{{- .Values.postgres.password | default "changeme" }}
{{- else if .Values.postgresql.auth -}}
{{- .Values.postgresql.auth.password }}
{{- else -}}
{{- "changeme" }}
{{- end -}}
{{- end }}

{{/*
PostgreSQL database
*/}}
{{- define "agenticwork.postgresql.database" -}}
{{- if and .Values.postgres .Values.postgres.enabled -}}
{{- .Values.postgres.database | default "agenticwork" }}
{{- else if .Values.postgresql.auth -}}
{{- .Values.postgresql.auth.database }}
{{- else -}}
{{- "agenticwork" }}
{{- end -}}
{{- end }}

{{/*
Milvus service name for Milvus subchart
IMPORTANT: Milvus subchart creates services with pattern {{ .Release.Name }}-milvus
NOT {{ include "agenticwork.fullname" . }}-milvus
*/}}
{{- define "agenticwork.milvus.serviceName" -}}
{{- printf "%s-milvus" .Release.Name }}
{{- end }}

{{/*
Milvus port
*/}}
{{- define "agenticwork.milvus.port" -}}
{{- if .Values.milvus.service }}
{{- .Values.milvus.service.port | default 19530 }}
{{- else }}
{{- 19530 }}
{{- end }}
{{- end }}


{{/*
Etcd service name (dependency of Milvus)
IMPORTANT: Etcd subchart creates services with pattern {{ .Release.Name }}-etcd
*/}}
{{- define "agenticwork.etcd.serviceName" -}}
{{- printf "%s-etcd" .Release.Name }}
{{- end }}

{{/*
Etcd port
*/}}
{{- define "agenticwork.etcd.port" -}}
{{- 2379 }}
{{- end }}

{{/*
MinIO service name (dependency of Milvus)
IMPORTANT: MinIO subchart creates services with pattern {{ .Release.Name }}-minio
*/}}
{{- define "agenticwork.minio.serviceName" -}}
{{- printf "%s-minio" .Release.Name }}
{{- end }}

{{/*
MinIO port
*/}}
{{- define "agenticwork.minio.port" -}}
{{- 9000 }}
{{- end }}

{{/*
API service name
NOTE: API is a primary service, not a subchart
*/}}
{{- define "agenticwork.api.serviceName" -}}
{{- printf "%s-api" (include "agenticwork.fullname" .) }}
{{- end }}

{{/*
API port
*/}}
{{- define "agenticwork.api.port" -}}
{{- .Values.api.service.port | default 8000 }}
{{- end }}

{{/*
UI service name
NOTE: UI is a primary service, not a subchart
*/}}
{{- define "agenticwork.ui.serviceName" -}}
{{- printf "%s-ui" (include "agenticwork.fullname" .) }}
{{- end }}

{{/*
UI port
*/}}
{{- define "agenticwork.ui.port" -}}
{{- .Values.ui.service.port | default 80 }}
{{- end }}

{{/*
Ollama service name
NOTE: Ollama is a primary service, not a subchart
*/}}
{{- define "agenticwork.ollama.serviceName" -}}
{{- printf "%s-ollama" (include "agenticwork.fullname" .) }}
{{- end }}

{{/*
Ollama port
*/}}
{{- define "agenticwork.ollama.port" -}}
{{- .Values.ollama.service.port | default 11434 }}
{{- end }}

{{/*
Ollama base URL
*/}}
{{- define "agenticwork.ollama.url" -}}
{{- printf "http://%s:%s" (include "agenticwork.ollama.serviceName" .) (include "agenticwork.ollama.port" .) }}
{{- end }}

{{/*
Secret name helper
*/}}
{{- define "agenticwork.secretName" -}}
{{- printf "%s-secret" (include "agenticwork.fullname" .) }}
{{- end }}

{{/*
AWS Secret name helper
*/}}
{{- define "agenticwork.awsSecretName" -}}
{{- printf "%s-aws-secrets" (include "agenticwork.fullname" .) }}
{{- end }}

